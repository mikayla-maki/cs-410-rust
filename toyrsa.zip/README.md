Mikayla Maki

HW 2: Toy RSA

Writeup:
Began by fleshing out the project structure as specified in the assignment text.
Then I started trying to write tests for the lambda function as well as my personal
implementation of LCM... then I realized we already had everything we needed in Bart's library.
From there it was pretty quick to just run through all of the functions. It did take me a
minute to realize that the u32s and u64s where intermixed on purpose, and that I needed to stop 
trying to make them all the same. Then I wrote a test function which generated 10 random keys
and tested each key with 10 random values. Seems to work well. Finally, I went through and
commented, cleaned up, and generally got the assignment ready for submission. (also had some
fun and implemented a command line interface for this assignment)