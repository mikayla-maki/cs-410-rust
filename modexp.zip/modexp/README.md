Mikayla Maki

HW 1: Modular Exponentiation

Writeup:
Started by building out the scaffold using the code snippets from the assignment.
Then implemented the actual function, had to decide between messing with the 
function signature (bad form, bad aesthetics) and shadowing all the variables.
I chose to shadow them. Then I just had to fix a small bug with the command
line arguments,,, and that's it! 😸